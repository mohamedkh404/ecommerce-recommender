from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from recommender import HybridRecommender

app = FastAPI(title="E-commerce Recommender API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # في الإنتاج خليه دومين موقعك فقط
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

reco = HybridRecommender()

class Interaction(BaseModel):
    user_id: str
    product_id: int
    score: float = 1.0

@app.get("/")
def root():
    return {"status": "ok", "msg": "Recommender running 🚀"}

@app.get("/products")
def products():
    return reco.products

@app.post("/interactions")
def add_interaction(payload: Interaction):
    reco.add_interaction(payload.user_id, payload.product_id, payload.score)
    return {"ok": True}

@app.get("/recommend")
def recommend(
    user_id: Optional[str] = None,
    query: Optional[str] = None,
    based_on: Optional[int] = Query(default=None),
    top_k: int = 10,
    alpha: float = 0.6,
):
    return {"items": reco.recommend(user_id=user_id, query=query, based_on=based_on, top_k=top_k, alpha=alpha)}

@app.post("/reload")
def reload_index():
    reco.reload()
    return {"ok": True}
