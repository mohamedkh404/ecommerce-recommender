from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Tuple
from collections import Counter, defaultdict
import json
import math
import csv
import re

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
STORE_DIR = ROOT / "storage"
STORE_DIR.mkdir(parents=True, exist_ok=True)

PRODUCTS_CSV = DATA_DIR / "products.csv"
INTERACTIONS_JSON = STORE_DIR / "interactions.json"  # {user_id: {product_id: score}}

_word_re = re.compile(r"[a-zA-Z0-9]+")

def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _word_re.findall(text or "") if len(t) > 1]

def load_products() -> List[Dict]:
    items = []
    with open(PRODUCTS_CSV, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            row["id"] = int(row["id"])
            row["price"] = float(row["price"])
            items.append(row)
    return items

def load_interactions() -> Dict[str, Dict[str, float]]:
    if not INTERACTIONS_JSON.exists():
        return {}
    try:
        return json.loads(INTERACTIONS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_interactions(store: Dict[str, Dict[str, float]]) -> None:
    INTERACTIONS_JSON.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")

# ---------- Content-Based TF-IDF ----------
class ContentIndex:
    def __init__(self, products: List[Dict]):
        self.products = products
        self.docs: List[List[str]] = []
        self.vocab_idf: Dict[str, float] = {}
        self.doc_vecs: List[Dict[str, float]] = []
        self._build()

    def _build(self):
        texts = []
        for p in self.products:
            txt = f"{p['name']} {p['category']} {p.get('description','')}"
            texts.append(txt)
            self.docs.append(_tokenize(txt))

        # DF
        df = Counter()
        for tokens in self.docs:
            df.update(set(tokens))

        n = len(self.docs)
        self.vocab_idf = {w: math.log((1 + n) / (1 + c)) + 1.0 for w, c in df.items()}

        # TF-IDF per doc
        self.doc_vecs = []
        for tokens in self.docs:
            tf = Counter(tokens)
            vec = {w: (tf[w] / len(tokens)) * self.vocab_idf.get(w, 0.0) for w in tf}
            self.doc_vecs.append(vec)

    @staticmethod
    def _cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
        if not a or not b:
            return 0.0
        common = set(a.keys()) & set(b.keys())
        dot = sum(a[k] * b[k] for k in common)
        na = math.sqrt(sum(v * v for v in a.values()))
        nb = math.sqrt(sum(v * v for v in b.values()))
        return dot / (na * nb) if na and nb else 0.0

    def similar_to_product(self, product_id: int, top_k: int = 10, exclude_self: bool = True) -> List[Tuple[int, float]]:
        idx = next((i for i, p in enumerate(self.products) if p["id"] == product_id), None)
        if idx is None:
            return []
        target = self.doc_vecs[idx]
        sims = []
        for j, vec in enumerate(self.doc_vecs):
            if exclude_self and j == idx:
                continue
            sims.append((self.products[j]["id"], self._cosine(target, vec)))
        sims.sort(key=lambda x: x[1], reverse=True)
        return sims[:top_k]

    def similar_to_query(self, query: str, top_k: int = 10) -> List[Tuple[int, float]]:
        tokens = _tokenize(query)
        if not tokens:
            return []
        tf = Counter(tokens)
        qvec = {w: (tf[w] / len(tokens)) * self.vocab_idf.get(w, 0.0) for w in tf}
        sims = []
        for j, vec in enumerate(self.doc_vecs):
            sims.append((self.products[j]["id"], self._cosine(qvec, vec)))
        sims.sort(key=lambda x: x[1], reverse=True)
        return sims[:top_k]

# ---------- Collaborative (Item-Item from user feedback) ----------
class CollabIndex:
    def __init__(self, products: List[Dict], interactions: Dict[str, Dict[str, float]]):
        self.products = products
        self.interactions = interactions
        self.item_users: Dict[int, Dict[str, float]] = defaultdict(dict)  # item -> {user: score}
        self._build()

    def _build(self):
        self.item_users.clear()
        for user, items in self.interactions.items():
            for pid_str, score in items.items():
                self.item_users[int(pid_str)][user] = float(score)

    @staticmethod
    def _cosine_users(a: Dict[str, float], b: Dict[str, float]) -> float:
        common = set(a.keys()) & set(b.keys())
        if not common:
            return 0.0
        dot = sum(a[u] * b[u] for u in common)
        na = math.sqrt(sum(v * v for v in a.values()))
        nb = math.sqrt(sum(v * v for v in b.values()))
        return dot / (na * nb) if na and nb else 0.0

    def similar_items(self, product_id: int, top_k: int = 10) -> List[Tuple[int, float]]:
        target = self.item_users.get(product_id, {})
        sims = []
        for pid, vec in self.item_users.items():
            if pid == product_id:
                continue
            sims.append((pid, self._cosine_users(target, vec)))
        sims.sort(key=lambda x: x[1], reverse=True)
        return sims[:top_k]

    def recommend_for_user(self, user_id: str, top_k: int = 10) -> List[Tuple[int, float]]:
        user_items = self.interactions.get(user_id, {})
        # score candidate by similarity to items the user liked
        scores = defaultdict(float)
        for pid_str, rating in user_items.items():
            pid = int(pid_str)
            for other, sim in self.similar_items(pid, top_k=50):
                if str(other) in user_items:  # skip already seen
                    continue
                scores[other] += sim * float(rating)
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return ranked[:top_k]

# ---------- Hybrid ----------
class HybridRecommender:
    def __init__(self):
        self.products = load_products()
        self.content = ContentIndex(self.products)
        self.interactions = load_interactions()
        self.collab = CollabIndex(self.products, self.interactions)
        self.product_by_id = {p["id"]: p for p in self.products}

    def reload(self):
        self.__init__()

    def add_interaction(self, user_id: str, product_id: int, score: float = 1.0):
        store = load_interactions()
        store.setdefault(user_id, {})
        store[user_id][str(product_id)] = float(score)
        save_interactions(store)
        self.interactions = store
        self.collab = CollabIndex(self.products, self.interactions)

    def recommend(
        self,
        user_id: str | None = None,
        query: str | None = None,
        based_on: int | None = None,
        top_k: int = 10,
        alpha: float = 0.6,  # content weight
    ) -> List[Dict]:
        content_scores = defaultdict(float)
        collab_scores = defaultdict(float)

        if query:
            for pid, s in self.content.similar_to_query(query, top_k=top_k * 3):
                content_scores[pid] = max(content_scores[pid], s)

        if based_on:
            for pid, s in self.content.similar_to_product(based_on, top_k=top_k * 3):
                content_scores[pid] = max(content_scores[pid], s)
            for pid, s in self.collab.similar_items(based_on, top_k=top_k * 3):
                collab_scores[pid] = max(collab_scores[pid], s)

        if user_id:
            for pid, s in self.collab.recommend_for_user(user_id, top_k=top_k * 3):
                collab_scores[pid] = max(collab_scores[pid], s)

        # combine
        combined = defaultdict(float)
        for pid in set(list(content_scores.keys()) + list(collab_scores.keys())):
            combined[pid] = alpha * content_scores.get(pid, 0.0) + (1 - alpha) * collab_scores.get(pid, 0.0)

        ranked = sorted(combined.items(), key=lambda x: x[1], reverse=True)
        out = []
        for pid, score in ranked[:top_k]:
            p = self.product_by_id.get(pid)
            if not p:
                continue
            out.append({
                "id": pid,
                "name": p["name"],
                "category": p["category"],
                "price": p["price"],
                "description": p.get("description", ""),
                "image": p.get("image", ""),
                "score": round(float(score), 5),
            })
        return out
