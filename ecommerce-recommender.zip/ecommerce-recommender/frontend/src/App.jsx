import React, { useEffect, useMemo, useState } from "react";

const API_BASE = "http://127.0.0.1:8000";

function ProductCard({ p, onLike }) {
  return (
    <div className="rounded-2xl overflow-hidden bg-white border border-slate-200 shadow hover:shadow-lg transition">
      {p.image && <img src={p.image} alt={p.name} className="w-full h-40 object-cover" />}
      <div className="p-4">
        <div className="text-sm text-slate-500">{p.category}</div>
        <h3 className="font-semibold text-lg">{p.name}</h3>
        <div className="mt-1 font-bold">${p.price}</div>
        {"score" in p && (
          <div className="mt-1 text-xs text-slate-500">Score: {p.score}</div>
        )}
        <p className="text-sm text-slate-600 mt-2 line-clamp-2">{p.description}</p>
        {onLike && (
          <button
            onClick={() => onLike(p.id)}
            className="mt-3 w-full py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700"
          >
            👍 Like
          </button>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [userId, setUserId] = useState("user_1");
  const [query, setQuery] = useState("");
  const [basedOn, setBasedOn] = useState(null);
  const [recs, setRecs] = useState([]);
  const [alpha, setAlpha] = useState(0.6);

  useEffect(() => {
    fetch(`${API_BASE}/products`).then(r => r.json()).then(setProducts);
  }, []);

  const selected = useMemo(() => products.find(p => p.id === Number(basedOn)), [products, basedOn]);

  const getRecs = () => {
    const params = new URLSearchParams();
    if (userId) params.append("user_id", userId);
    if (query) params.append("query", query);
    if (basedOn) params.append("based_on", basedOn);
    params.append("top_k", "8");
    params.append("alpha", String(alpha));
    fetch(`${API_BASE}/recommend?` + params.toString())
      .then(r => r.json())
      .then(d => setRecs(d.items || []));
  };

  const like = async (pid) => {
    await fetch(`${API_BASE}/interactions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId, product_id: pid, score: 1.0 })
    });
    getRecs();
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <header className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3 mb-6">
        <div>
          <h1 className="text-3xl font-extrabold">🛒 AI Recommender</h1>
          <p className="text-slate-600">Hybrid (Content + Collaborative)</p>
        </div>
        <div className="flex gap-3">
          <input
            className="border rounded-xl px-3 py-2"
            placeholder="user id"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
          <button onClick={getRecs} className="px-4 py-2 rounded-xl bg-slate-900 text-white">Get Recs</button>
        </div>
      </header>

      <section className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="md:col-span-2 bg-white border border-slate-200 rounded-2xl p-4">
          <div className="flex gap-3">
            <input
              className="flex-1 border rounded-xl px-3 py-2"
              placeholder="Search query (e.g. laptop, running, leather)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <select
              className="border rounded-xl px-3 py-2"
              value={basedOn || ""}
              onChange={(e) => setBasedOn(e.target.value || null)}
            >
              <option value="">Based on product…</option>
              {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <button onClick={getRecs} className="px-4 py-2 rounded-xl bg-blue-600 text-white">Recommend</button>
          </div>
          <div className="mt-4">
            <label className="text-sm mr-2">Content weight α = {alpha.toFixed(2)}</label>
            <input
              type="range" min="0" max="1" step="0.05" value={alpha}
              onChange={e => setAlpha(parseFloat(e.target.value))}
              className="w-full"
            />
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4">
          <h3 className="font-semibold mb-2">Selected:</h3>
          {selected ? <ProductCard p={selected} /> : <p className="text-slate-500 text-sm">Pick a product above.</p>}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-3">Recommendations</h2>
        {recs.length === 0 ? (
          <p className="text-slate-500">No recommendations yet. Try a query or like products.</p>
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {recs.map(p => <ProductCard key={p.id} p={p} onLike={like} />)}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="text-xl font-bold mb-3">All Products</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map(p => <ProductCard key={p.id} p={p} onLike={like} />)}
        </div>
      </section>
    </div>
  );
}
