const API_URL = "http://127.0.0.1:5000"; // لازم نفس البورت اللي شغال عليه الباك إند

export async function getRecommendations(userId) {
  const response = await fetch(`${API_URL}/recommend?user=${userId}`);
  return response.json();
}
